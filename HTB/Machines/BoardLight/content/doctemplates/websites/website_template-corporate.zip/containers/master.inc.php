<?php
// File generated to link to the master file - DO NOT MODIFY - It is just an include
if (! defined('USEDOLIBARRSERVER') && ! defined('USEDOLIBARREDITOR')) {
    if (! defined('USEEXTERNALSERVER')) define('USEEXTERNALSERVER', 1);
    require_once '/home/ldestailleur/git/dolibarr_dev/htdocs/master.inc.php';
}
?>
